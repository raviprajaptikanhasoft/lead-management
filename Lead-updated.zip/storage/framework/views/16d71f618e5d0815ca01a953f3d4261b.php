<?php $__env->startSection('content'); ?>
<?php echo \Livewire\Livewire::styles(); ?>


<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">

            <?php if(session('status')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('status')); ?>

            </div>
            <?php endif; ?>

            <!-- <?php echo e(__('You are logged in!')); ?> -->
            <form class="form-inline" method="POST" name="create-info" action="<?php echo e(route('add-info')); ?>">
                <?php echo csrf_field(); ?>
                <div class="container">
                    <div class="row g-2">
                        <div class="col-md-3">
                            <input type="text" placeholder="Lead name" class="form-control" name="text1" required>
                        </div>
                        <div class="col-md-3">
                            <input type="text" placeholder="Designation" class="form-control" name="text2" required>
                        </div>
                        <div class="col-md-3">
                            <input type="text" placeholder="Post URL" class="form-control" name="text3" required>
                        </div>
                        <div class="col-md-3">
                            <input type="text" placeholder="Description" class="form-control" name="text4" required>
                        </div>

                        
                        <div class="col-md-3">
                            <input type="text" placeholder="Company Name" class="form-control" name="text5">
                        </div>

                        
                        <div class="col-md-3">
                            <input type="text" placeholder="LinkedIn Profile" class="form-control" name="text6">
                        </div>

                        
                        <div class="col-md-3">
                            <input type="email" placeholder="Email" class="form-control" name="text7">
                        </div>

                        
                        <div class="col-md-3">
                            <input type="text" placeholder="Phone" class="form-control" name="text8">
                        </div>

                        <div class="col-12 text-end mt-3">
                            <button type="reset" class="btn btn-light">Reset</button>
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
                    <!-- <br/>
                        <div class="row">
                            <div class="col-sm-6">
                                <input type="text" placeholder="Post URL.." class="form-control" name="text3" required>
                            </div>
                            <div class="col-sm-6">
                                <input type="text" placeholder="Description.." class="form-control" name="text4" required>
                            </div>
                        </div>
                        <br/> -->

                </div>
            </form>
            <br />
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('home')->html();
} elseif ($_instance->childHasBeenRendered('0XlUZKa')) {
    $componentId = $_instance->getRenderedChildComponentId('0XlUZKa');
    $componentTag = $_instance->getRenderedChildComponentTagName('0XlUZKa');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('0XlUZKa');
} else {
    $response = \Livewire\Livewire::mount('home');
    $html = $response->html();
    $_instance->logRenderedChild('0XlUZKa', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        </div>
    </div>
</div>
<?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Lead\resources\views/home.blade.php ENDPATH**/ ?>