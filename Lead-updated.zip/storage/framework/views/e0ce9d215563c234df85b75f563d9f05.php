<div>

    <div class="mb-3">
        <div class="row align-items-center">
            
            <div class="col-lg-2 col-md-3 mt-4">
                <div class="p-2 text-center bg-primary text-white rounded fw-bold">
                    Total Leads: <?php echo e($total_records); ?>

                </div>
            </div>


            <div class="col-lg-10">
                <div class="row">
                    

                    <div class="col-lg-2 col-md-3 <?php echo e(Auth::user()->isadmin == 1 ? 'ms-auto' : 'ms-auto col-md-4'); ?>">
                        <label class="form-label small text-muted mb-1">&nbsp;</label>
                        <input wire:model="search" type="text" placeholder="Search..." class="form-control">
                    </div>

                    <?php if(Auth::user()->isadmin == 1): ?>
                        
                        <div class="col-lg-2 col-md-3">
                            <label class="form-label small text-muted mb-0">From Date</label>
                            <input wire:model="date_from" type="date" class="form-control">
                        </div>

                        
                        <div class="col-lg-2 col-md-3">
                            <label class="form-label small text-muted mb-0">To Date</label>
                            <input wire:model="date_to" type="date" class="form-control">
                        </div>

                        
                        <div class="col-lg-2 col-md-3">
                            <label class="form-label small text-muted mb-0">User</label>
                            <select wire:model="filter_user" class="form-control">
                                <option value="">All Users</option>
                                <?php $__currentLoopData = $all_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-lg-2 col-md-2">
                            <label class="form-label small text-muted mb-1">&nbsp;</label>
                            <button wire:click="resetFilters" class="btn btn-secondary w-100">
                                Reset Filters
                            </button>
                        </div>

                        
                        <div class="col-lg-2 col-md-2">
                            <label class="form-label small text-muted mb-1 d-block">&nbsp;</label>
                            <button wire:click="exportCsv" class="btn btn-success w-100" <?php if($all_users->count() == 0): ?> disabled <?php endif; ?>>
                                <i class="bi bi-filetype-csv"></i> CSV
                            </button>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    

    <table id="example" class="display table table-bordered" style="width:100%">
        <thead>
            <tr>
                <th wire:click="sortBy('informations.text1')">Lead name</th>
                <th wire:click="sortBy('informations.text2')">Designation</th>
                <th wire:click="sortBy('informations.text3')">Post URL</th>
                <th wire:click="sortBy('informations.text4')">description</th>
                <th wire:click="sortBy('informations.text5')">Company Name</th>
                <th wire:click="sortBy('informations.text6')">Linkedin Profile</th>
                <th wire:click="sortBy('informations.text7')">Email</th>
                <th wire:click="sortBy('informations.text8')">Phone</th>
                <th wire:click="sortBy('users.name')">createdBy</th>
                <th wire:click="sortBy('informations.created_at')">date</th>
            </tr>
        </thead>
        <tbody wire:poll.750ms>
            <?php if($users->count() > 0): ?>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(substr($user->text1, 0, 50)); ?></td>
                        <td><?php echo e(substr($user->text2, 0, 50)); ?></td>
                        <td title="<?php echo e($user->text3); ?>">
                            <a target="_blank" href="<?php echo e($user->text3); ?>">
                                <?php echo e(substr($user->text3, 0, 50)); ?>

                            </a>
                        </td>
                        <td class="text-wrap text-break"><?php echo e(substr($user->text4, 0, 50)); ?></td>
                        <td><?php echo e(substr($user->text5, 0, 50)); ?></td>
                        <td><?php echo e(substr($user->text6, 0, 50)); ?></td>
                        
                        <td>
                            <div class="d-inline-block" data-bs-toggle="tooltip" data-bs-placement="top" title="<?php echo e($user->text7); ?>">
                                <?php echo e(strlen($user->text7) > 25 ? substr($user->text7, 0, 25) . '...' : $user->text7); ?>

                            </div>
                        </td>
                        <td><?php echo e(substr($user->text8, 0, 50)); ?></td>
                        <td><?php echo e($user->user->name); ?></td>
                        <td><?php echo e($user->created_at); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr>
                    <td colspan="10" class="text-center text-muted py-3">
                        No records found
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="d-flex justify-content-center">
        <?php echo e($users->links('livewire-pagination')); ?>

    </div>
</div>

<?php $__env->startPush('styles'); ?>
    <style>
        .pagination .page-link {
            font-size: 14px;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('livewire:load', function () {
        initTooltips();

        Livewire.hook('message.processed', (message, component) => {
            initTooltips();
        });
    });

    function initTooltips() {
        document.querySelectorAll('[data-bs-toggle="tooltip"]').forEach(function (el) {
            new bootstrap.Tooltip(el);
        });
    }
</script>
<?php $__env->stopPush(); ?><?php /**PATH D:\Lead\resources\views/livewire/home.blade.php ENDPATH**/ ?>