<div>

    <div class="mb-3">
        <div class="row align-items-center">
            {{-- Total Leads --}}
            <div class="col-lg-2 col-md-3 mt-4">
                <div class="p-2 text-center bg-primary text-white rounded fw-bold">
                    Total Leads: {{ $total_records }}
                </div>
            </div>


            <div class="col-lg-10">
                <div class="row">
                    {{-- Search (Right-Aligned) --}}

                    <div class="col-lg-2 col-md-3 {{ Auth::user()->isadmin == 1 ? 'ms-auto' : 'ms-auto col-md-4' }}">
                        <label class="form-label small text-muted mb-1">&nbsp;</label>
                        <input wire:model="search" type="text" placeholder="Search..." class="form-control">
                    </div>

                    @if (Auth::user()->isadmin == 1)
                        {{-- Date From --}}
                        <div class="col-lg-2 col-md-3">
                            <label class="form-label small text-muted mb-0">From Date</label>
                            <input wire:model="date_from" type="date" class="form-control">
                        </div>

                        {{-- Date To --}}
                        <div class="col-lg-2 col-md-3">
                            <label class="form-label small text-muted mb-0">To Date</label>
                            <input wire:model="date_to" type="date" class="form-control">
                        </div>

                        {{-- User Filter --}}
                        <div class="col-lg-2 col-md-3">
                            <label class="form-label small text-muted mb-0">User</label>
                            <select wire:model="filter_user" class="form-control">
                                <option value="">All Users</option>
                                @foreach ($all_users as $user)
                                    <option value="{{ $user->id }}">{{ $user->name }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="col-lg-2 col-md-2">
                            <label class="form-label small text-muted mb-1">&nbsp;</label>
                            <button wire:click="resetFilters" class="btn btn-secondary w-100">
                                Reset Filters
                            </button>
                        </div>

                        {{-- Export CSV --}}
                        <div class="col-lg-2 col-md-2">
                            <label class="form-label small text-muted mb-1 d-block">&nbsp;</label>
                            <button wire:click="exportCsv" class="btn btn-success w-100" @if($all_users->count() == 0) disabled @endif>
                                <i class="bi bi-filetype-csv"></i> CSV
                            </button>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>

    {{-- <span class="alert alert-primary">
        <label><b>Total Leads : {{ $all_users->count() }}</b></label>
    </span>
    <input wire:model="search" type="text" placeholder="Search..." style="float: right; margin:2% 2%; width:25%"
        class="form-control"> --}}

    <table id="example" class="display table table-bordered" style="width:100%">
        <thead>
            <tr>
                <th wire:click="sortBy('informations.text1')">Lead name</th>
                <th wire:click="sortBy('informations.text2')">Designation</th>
                <th wire:click="sortBy('informations.text3')">Post URL</th>
                <th wire:click="sortBy('informations.text4')">description</th>
                <th wire:click="sortBy('informations.text5')">Company Name</th>
                <th wire:click="sortBy('informations.text6')">Linkedin Profile</th>
                <th wire:click="sortBy('informations.text7')">Email</th>
                <th wire:click="sortBy('informations.text8')">Phone</th>
                <th wire:click="sortBy('users.name')">createdBy</th>
                <th wire:click="sortBy('informations.created_at')">date</th>
            </tr>
        </thead>
        <tbody wire:poll.750ms>
            @if ($users->count() > 0)
                @foreach ($users as $user)
                    <tr>
                        <td>{{ substr($user->text1, 0, 50) }}</td>
                        <td>{{ substr($user->text2, 0, 50) }}</td>
                        <td title="{{ $user->text3 }}">
                            <a target="_blank" href="{{ $user->text3 }}">
                                {{ substr($user->text3, 0, 50) }}
                            </a>
                        </td>
                        <td class="text-wrap text-break">{{ substr($user->text4, 0, 50) }}</td>
                        <td>{{ substr($user->text5, 0, 50) }}</td>
                        <td>{{ substr($user->text6, 0, 50) }}</td>
                        {{-- <td>{{ substr($user->text7, 0, 50) }}</td> --}}
                        <td>
                            <div class="d-inline-block" data-bs-toggle="tooltip" data-bs-placement="top" title="{{ $user->text7 }}">
                                {{ strlen($user->text7) > 25 ? substr($user->text7, 0, 25) . '...' : $user->text7 }}
                            </div>
                        </td>
                        <td>{{ substr($user->text8, 0, 50) }}</td>
                        <td>{{ $user->user->name }}</td>
                        <td>{{ $user->created_at }}</td>
                    </tr>
                @endforeach
            @else
                <tr>
                    <td colspan="10" class="text-center text-muted py-3">
                        No records found
                    </td>
                </tr>
            @endif
        </tbody>
    </table>

    <div class="d-flex justify-content-center">
        {{ $users->links('livewire-pagination') }}
    </div>
</div>

@push('styles')
    <style>
        .pagination .page-link {
            font-size: 14px;
        }
    </style>
@endpush

@push('scripts')
<script>
    document.addEventListener('livewire:load', function () {
        initTooltips();

        Livewire.hook('message.processed', (message, component) => {
            initTooltips();
        });
    });

    function initTooltips() {
        document.querySelectorAll('[data-bs-toggle="tooltip"]').forEach(function (el) {
            new bootstrap.Tooltip(el);
        });
    }
</script>
@endpush