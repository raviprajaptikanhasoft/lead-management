@if ($paginator->hasPages())
    <ul class="pagination">
        {{-- Previous Page Link --}}
        @if ($paginator->onFirstPage())
            <li class="disabled page-item"><span class="page-link">&lsaquo;</span></li>
        @else
            <li class="page-item"><a class="page-link" href="#" wire:click="previousPage" rel="prev">&lsaquo;</a></li>
        @endif

        {{-- Next Page Link --}}
        @if ($paginator->hasMorePages())
            <li class="page-item"><a class="page-link" href="#" wire:click="nextPage" rel="next">&rsaquo;</a></li>
        @else
            <li class="disabled page-item"><span class="page-link">&rsaquo;</span></li>
        @endif
    </ul>
@endif
