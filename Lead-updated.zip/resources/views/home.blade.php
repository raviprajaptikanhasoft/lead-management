@extends('layouts.app')

@section('content')
@livewireStyles

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">

            @if (session('status'))
            <div class="alert alert-success" role="alert">
                {{ session('status') }}
            </div>
            @endif

            <!-- {{ __('You are logged in!') }} -->
            <form class="form-inline" method="POST" name="create-info" action="{{route('add-info')}}">
                @csrf
                <div class="container">
                    <div class="row g-2">
                        <div class="col-md-3">
                            <input type="text" placeholder="Lead name" class="form-control" name="text1" required>
                        </div>
                        <div class="col-md-3">
                            <input type="text" placeholder="Designation" class="form-control" name="text2" required>
                        </div>
                        <div class="col-md-3">
                            <input type="text" placeholder="Post URL" class="form-control" name="text3" required>
                        </div>
                        <div class="col-md-3">
                            <input type="text" placeholder="Description" class="form-control" name="text4" required>
                        </div>

                        {{-- Company Name --}}
                        <div class="col-md-3">
                            <input type="text" placeholder="Company Name" class="form-control" name="text5">
                        </div>

                        {{-- LinkedIn Profile --}}
                        <div class="col-md-3">
                            <input type="text" placeholder="LinkedIn Profile" class="form-control" name="text6">
                        </div>

                        {{-- Email --}}
                        <div class="col-md-3">
                            <input type="email" placeholder="Email" class="form-control" name="text7">
                        </div>

                        {{-- Phone --}}
                        <div class="col-md-3">
                            <input type="text" placeholder="Phone" class="form-control" name="text8">
                        </div>

                        <div class="col-12 text-end mt-3">
                            <button type="reset" class="btn btn-light">Reset</button>
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
                    <!-- <br/>
                        <div class="row">
                            <div class="col-sm-6">
                                <input type="text" placeholder="Post URL.." class="form-control" name="text3" required>
                            </div>
                            <div class="col-sm-6">
                                <input type="text" placeholder="Description.." class="form-control" name="text4" required>
                            </div>
                        </div>
                        <br/> -->

                </div>
            </form>
            <br />
            @livewire('home')

        </div>
    </div>
</div>
@livewireScripts
@endsection