<?php return array (
  'home' => 'App\\Http\\Livewire\\Home',
);