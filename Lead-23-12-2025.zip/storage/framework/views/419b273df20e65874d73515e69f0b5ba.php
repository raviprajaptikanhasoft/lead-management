<div>
    <!-- Modal -->
    <div wire:ignore.self class="modal fade" id="addLeadModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">

                <div class="modal-header">
                    <h5 class="modal-title">Add New Information</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <form wire:submit.prevent="saveLead" onkeydown="return event.key !== 'Enter';">
                    <div class="modal-body">
                        <div class="row g-2">

                            <div class="col-md-6">
                                <label class="form-label">Lead Name</label>
                                <input type="text" class="form-control" wire:model="text1" placeholder="Lead Name">
                                <?php $__errorArgs = ['text1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Designation</label>
                                <input type="text" class="form-control" wire:model="text2" placeholder="Designation">
                                <?php $__errorArgs = ['text2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Post URL</label>
                                <input type="text" class="form-control" wire:model="text3" placeholder="Post URL">
                                <?php $__errorArgs = ['text3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Description</label>
                                <input type="text" class="form-control" wire:model="text4" placeholder="Description">
                                <?php $__errorArgs = ['text4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Company Name</label>
                                <input type="text" class="form-control" wire:model="text5" placeholder="Company Name">
                                <?php $__errorArgs = ['text5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">LinkedIn Profile</label>
                                <input type="text" class="form-control" wire:model="text6" placeholder="LinkedIn Profile">
                                <?php $__errorArgs = ['text6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Email</label>
                                <input type="email" class="form-control" wire:model="text7" placeholder="Email">
                                <?php $__errorArgs = ['text7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Phone</label>
                                <input type="text" class="form-control" wire:model="text8" placeholder="Phone">
                                <?php $__errorArgs = ['text8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Country</label>
                                
                                <select class="form-select" wire:model="text9">
                                    <option value="">Select Country</option>

                                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($country['name']); ?>">
                                            <?php echo e($country['name']); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['text9'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-secondary" wire:click="resetForm">Reset</button>
                        <button type="submit" class="btn btn-success">Save Lead</button>
                    </div>
                </form>

            </div>
        </div>
    </div>

    <script>
        (function () {
            // helper: emit to Livewire (v2) or dispatch (v3)
            function sendResetToLivewire() {
                if (window.Livewire && typeof window.Livewire.emit === 'function') {
                    window.Livewire.emit('resetLeadForm');        // v2
                } else if (window.Livewire && typeof window.Livewire.dispatch === 'function') {
                    window.Livewire.dispatch('resetLeadForm');    // v3
                } else if (window.dispatchEvent) {
                    // fallback custom event (component could listen to it)
                    window.dispatchEvent(new CustomEvent('resetLeadForm'));
                }
            }

            // show modal when Livewire triggers open
            window.addEventListener('open-add-lead-modal', () => {
                const modalEl = document.getElementById('addLeadModal');
                if (!modalEl) return;
                // ensure form cleared BEFORE showing (component does reset in openModal)
                const modal = new bootstrap.Modal(modalEl);
                modal.show();
            });

            // hide modal when Livewire tells to close
            window.addEventListener('close-add-lead-modal', () => {
                const modalEl = document.getElementById('addLeadModal');
                if (!modalEl) return;
                const modal = bootstrap.Modal.getInstance(modalEl);
                if (modal) modal.hide();
            });

            // when user closes modal manually (X, Cancel, backdrop), notify Livewire to reset
            document.addEventListener('DOMContentLoaded', function () {
                const modalEl = document.getElementById('addLeadModal');
                if (!modalEl) return;
                modalEl.addEventListener('hidden.bs.modal', function () {
                    // notify Livewire to reset component state
                    sendResetToLivewire();
                });
            });

            // Also attach the listener after Livewire load (in case component is injected later)
            document.addEventListener('livewire:load', function () {
                const modalEl = document.getElementById('addLeadModal');
                if (!modalEl) return;
                // avoid duplicate handlers
                modalEl.removeEventListener('hidden.bs.modal', () => {});
                modalEl.addEventListener('hidden.bs.modal', function () {
                    sendResetToLivewire();
                });
            });

        })();
    </script>
</div>
<?php /**PATH D:\Lead\resources\views/livewire/information/add-information.blade.php ENDPATH**/ ?>