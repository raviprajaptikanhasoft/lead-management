<?php $__env->startSection('content'); ?>
<?php echo \Livewire\Livewire::styles(); ?>


<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">

            <div class="d-flex justify-content-between align-items-center">
                <h4 class="mb-0">Leads Management</h4>

                
                <button class="btn btn-primary" data-bs-toggle="modal" wire:click="$emit('openAddLeadModal')" data-bs-target="#addLeadModal">
                    Add New Lead
                </button>
            </div>

            <?php if(session('status')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
            
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('add-lead')->html();
} elseif ($_instance->childHasBeenRendered('JjQ1wZA')) {
    $componentId = $_instance->getRenderedChildComponentId('JjQ1wZA');
    $componentTag = $_instance->getRenderedChildComponentTagName('JjQ1wZA');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('JjQ1wZA');
} else {
    $response = \Livewire\Livewire::mount('add-lead');
    $html = $response->html();
    $_instance->logRenderedChild('JjQ1wZA', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('home')->html();
} elseif ($_instance->childHasBeenRendered('GDobWcz')) {
    $componentId = $_instance->getRenderedChildComponentId('GDobWcz');
    $componentTag = $_instance->getRenderedChildComponentTagName('GDobWcz');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('GDobWcz');
} else {
    $response = \Livewire\Livewire::mount('home');
    $html = $response->html();
    $_instance->logRenderedChild('GDobWcz', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        </div>
    </div>
</div>

<?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Lead\resources\views/home.blade.php ENDPATH**/ ?>