<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Bootstrap Multiselect CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-multiselect@1.1.0/dist/css/bootstrap-multiselect.css">
    
    <!-- Select2 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />


    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>

    <?php echo $__env->yieldPushContent('styles'); ?>

    
    <?php echo \Livewire\Livewire::styles(); ?>

</head>

<body>
    <div id="app">

        
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <?php echo e(config('app.name', 'Laravel')); ?>

                </a>

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto">
                        <?php if(auth()->guard()->check()): ?>
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->routeIs('information.*') ? 'active fw-bold' : ''); ?>"
                                    href="<?php echo e(route('information.index')); ?>">
                                    <i class="bi bi-info-circle me-1"></i> Information
                                </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->routeIs('leads.*') ? 'active fw-bold' : ''); ?>"
                                    href="<?php echo e(route('leads.index')); ?>">
                                    <i class="bi bi-people me-1"></i> Leads
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>

                    <ul class="navbar-nav ms-auto">
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a>
                            </li>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                                    <?php echo e(Auth::user()->name); ?>

                                </a>

                                <div class="dropdown-menu dropdown-menu-end">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                        onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                        Logout
                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        
        <div id="notify-container" class="position-fixed top-0 end-0 p-3" style="z-index: 9999" wire:ignore></div>

        
        <main class="py-4 container">

            
            <?php echo e($slot ?? ''); ?>


            
            <?php echo $__env->yieldContent('content'); ?>

        </main>
    </div>

    
    <?php echo \Livewire\Livewire::scripts(); ?>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>

    <!-- select2 JS -->
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    
    <?php echo $__env->yieldPushContent('scripts'); ?>

    <script>
        var userId = $('meta[name="user-id"]').attr('content');

        if (userId !== '8') {
            // $(document).bind("contextmenu", function(e) {
            //     return false;
            // });
            $(document).on("cut", function(e) {
                alert('cut. not allowed!');
                e.preventDefault();
            });
            $(document).on("copy", function(e) {
                alert('copy. not allowed!');
                e.preventDefault();
            });
            $(document).keydown(function(e) {
                // console.log(e.which)
                if (e.which === 123) {
                    alert('not allowed!');
                    e.preventDefault();
                    return false
                }

            });
        }
        $(document).ready(function() {
            //$('#example').DataTable();
            // var table = $('#example').DataTable({
            //     "order": [[5, 'desc']]
            //     });
        });

        window.addEventListener('notify', event => {
        const { type, message } = event.detail;

        const alert = document.createElement('div');
        alert.className = `alert alert-${type} alert-dismissible fade show`;
        alert.innerHTML = `${message} <button type="button" class="btn-close" data-bs-dismiss="alert"></button>`;

        const container = document.getElementById('notify-container');
        container.appendChild(alert);

        setTimeout(() => {
            alert.classList.remove('show');
            setTimeout(() => alert.remove(), 500);
        }, 8000);
    });

    </script>
</body>

</html>
<?php /**PATH D:\Lead\resources\views/layouts/app.blade.php ENDPATH**/ ?>