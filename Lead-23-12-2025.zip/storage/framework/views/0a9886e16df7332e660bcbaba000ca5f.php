<div>
    <h3 class="mb-3">Leads Management</h3>

    
    <div class="row mb-3">
        <div class="col-md-2">
            <select wire:model="status" class="form-control">
                <option value="">All Status</option>
                <option value="New">New</option>
                <option value="Won">Won</option>
                <option value="Lost">Lost</option>
            </select>
        </div>

        <?php if(auth()->user()->isAdmin()): ?>
            <div class="col-md-2">
                <select wire:model="user" class="form-control">
                    <option value="">All Users</option>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($u->id); ?>"><?php echo e($u->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        <?php endif; ?>

        <div class="col-md-2">
            <input type="date" wire:model="date" class="form-control">
        </div>

        <div class="col-md-1">
            <button wire:click="resetFilters" class="btn btn-secondary w-100">Reset</button>
        </div>
    </div>

    
    <table class="table table-hover table-bordered align-middle">
        <thead class="table-light">
            <tr>
                
                <th>Lead name</th>
                <th>Post URL</th>
                <th>Country</th>
                <th>Status</th>
                <th>User name</th>
                <th>Created</th>
                <th width="220">Action</th>
            </tr>
        </thead>

        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    
                    <td><?php echo e($lead->information->text1 ?? '-'); ?></td>
                    <td><?php echo e($lead->information->text3 ?? '-'); ?></td>
                    <td><?php echo e($lead->information->text9 ?? '-'); ?></td>

                    
                    <td>
                        <span class="badge 
                            <?php if($lead->status === 'Won'): ?> bg-success
                            <?php elseif($lead->status === 'Lost'): ?> bg-danger
                            <?php else: ?> bg-secondary <?php endif; ?>">
                            <?php echo e($lead->status); ?>

                        </span>
                    </td>

                    <td><?php echo e($lead->user->name ?? '-'); ?></td>
                    <td><?php echo e($lead->created_at->format('d M Y')); ?></td>

                    <td>
                        <div class="d-flex gap-2">

                            
                            <select class="form-select form-select-sm" wire:change="updateStatus(<?php echo e($lead->id); ?>, $event.target.value)">
                                <option>Change Status</option>
                                
                                <option value="Won" <?php echo e($lead->status == 'Won' ? 'selected' : ''); ?>>Won</option>
                                <option value="Lost" <?php echo e($lead->status == 'Lost' ? 'selected' : ''); ?>>Lost</option>
                            </select>

                            <a wire:navigate href="<?php echo e(route('leads.show', $lead->id)); ?>" class="btn btn-sm btn-primary">View</a>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="text-center text-muted">
                        No leads found
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    
    <div class="d-flex justify-content-end">
        <?php echo e($leads->links('livewire-pagination')); ?>

    </div>
</div>
<?php /**PATH D:\Lead\resources\views/livewire/lead/lead-list.blade.php ENDPATH**/ ?>