<div class="container-fluid">
    <div class="card border-0 shadow-sm">

        
        <div class="card-header bg-white border-bottom d-flex justify-content-between align-items-center">
            <div>
                <h5 class="fw-bold mb-0">
                    <i class="bi bi-person-lines-fill text-primary me-2"></i>
                    Lead #<?php echo e($lead->id); ?>

                </h5>
                <small class="text-muted">
                    Created <?php echo e($lead->created_at->format('d M Y')); ?>

                </small>
            </div>

            
            <span
                class="badge rounded-pill px-3 py-2
                <?php if($lead->status === 'Won'): ?> bg-success
                <?php elseif($lead->status === 'Lost'): ?> bg-danger
                <?php else: ?> bg-secondary <?php endif; ?>">
                <?php echo e($lead->status ?? 'New'); ?>

            </span>
        </div>

        <div class="card-body">

            
            <div class="mb-4">
                <label class="form-label fw-semibold mb-2">
                    <i class="bi bi-pencil-square me-1"></i>
                    Add Note
                </label>

                <textarea wire:model.defer="note" class="form-control form-control-lg <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    rows="2" placeholder="Type your note and press Add..."></textarea>

                <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <div class="d-flex justify-content-end mt-3">
                    <button wire:click="addNote" class="btn btn-primary px-4">
                        <i class="bi bi-plus-circle me-1"></i> Add Note
                    </button>
                </div>
            </div>

            <hr class="my-4">

            
            <h6 class="fw-bold mb-4">
                <i class="bi bi-clock-history me-1"></i>
                Activity Timeline
            </h6>

            <div class="timeline">

                <?php $__empty_1 = true; $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="timeline-item">
                        <div class="timeline-icon">
                            <i class="bi bi-chat-dots"></i>
                        </div>

                        <div class="timeline-content">
                            <div class="d-flex justify-content-between">
                                <strong><?php echo e($n->user->name); ?></strong>
                                <small class="text-muted">
                                    <?php echo e($n->created_at->format('d M Y, h:i A')); ?>

                                </small>
                            </div>

                            <p class="mb-0 text-muted">
                                <?php echo e($n->note); ?>

                            </p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="text-center text-muted py-4">
                        <i class="bi bi-chat-square-dots fs-1 d-block mb-2"></i>
                        No notes added yet
                    </div>
                <?php endif; ?>

            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('styles'); ?>
    <style>
        .timeline {
            position: relative;
            margin-left: 20px;
            padding-left: 20px;
            border-left: 2px solid #dee2e6;
        }

        .timeline-item {
            position: relative;
            margin-bottom: 20px;
        }

        .timeline-icon {
            position: absolute;
            left: -30px;
            top: 0;
            width: 24px;
            height: 24px;
            background-color: #0d6efd;
            color: #fff;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .timeline-content {
            padding-left: 10px;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\Lead\resources\views/livewire/lead/show.blade.php ENDPATH**/ ?>