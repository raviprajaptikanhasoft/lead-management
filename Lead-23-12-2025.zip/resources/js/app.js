import './bootstrap';
import * as bootstrap from 'bootstrap';

// Make bootstrap available globally (optional)
window.bootstrap = bootstrap;