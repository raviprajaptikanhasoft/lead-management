<?php return array (
  'add-lead' => 'App\\Http\\Livewire\\AddLead',
  'dashboard' => 'App\\Http\\Livewire\\Dashboard',
  'home' => 'App\\Http\\Livewire\\Home',
  'information.add-information' => 'App\\Http\\Livewire\\Information\\AddInformation',
  'information.information-list' => 'App\\Http\\Livewire\\Information\\InformationList',
  'lead.lead-list' => 'App\\Http\\Livewire\\Lead\\LeadList',
  'lead.show' => 'App\\Http\\Livewire\\Lead\\Show',
  'leads' => 'App\\Http\\Livewire\\Leads',
);